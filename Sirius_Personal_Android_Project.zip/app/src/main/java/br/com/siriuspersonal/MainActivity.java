package br.com.siriuspersonal;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(13,13,13), CARD=Color.rgb(27,27,27), GOLD=Color.rgb(245,181,27), WHITE=Color.rgb(248,248,248), MUTED=Color.rgb(170,170,170);
    LinearLayout root, body, nav;
    EditText studentInput, notesInput, exerciseInput, setsInput, repsInput, restInput, loadInput;
    Spinner goalSpinner, splitSpinner, levelSpinner;
    ArrayList<JSONObject> draft = new ArrayList<>();
    SharedPreferences prefs;
    String screen="builder";
    final String[] exercises={"Supino reto","Supino inclinado com halteres","Crucifixo máquina","Crossover","Puxada frontal","Remada baixa","Remada curvada","Leg press","Agachamento","Cadeira extensora","Mesa flexora","Panturrilha","Desenvolvimento","Elevação lateral","Rosca direta","Rosca martelo","Tríceps na polia","Tríceps testa","Prancha","Abdominal crunch","Esteira","Bicicleta","Flexão de braço","Afundo"};
    final String[] goals={"Hipertrofia","Emagrecimento","Força","Condicionamento","Saúde geral"};
    final String[] splits={"Treino A — Peito e tríceps","Treino B — Costas e bíceps","Treino C — Pernas","Treino D — Ombros e abdômen","Corpo inteiro","Personalizado"};
    final String[] levels={"Iniciante","Intermediário","Avançado"};

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("sirius_local",MODE_PRIVATE); showShell(); showBuilder();}
    GradientDrawable bg(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke>0)d.setStroke(1,stroke);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,3,0,5);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void showShell(){
        root=column();root.setBackgroundColor(BG);
        LinearLayout header=column();header.setPadding(18,22,18,16);header.setBackground(bg(Color.rgb(22,22,22),0,0));
        header.addView(text("SIRIUS • MUSCULAÇÃO OLD SCHOOL",12,GOLD,true));
        header.addView(text("SIRIUS PERSONAL",27,WHITE,true));
        header.addView(text("Fichas de treino • offline • dados no aparelho",12,MUTED,false));root.addView(header);
        nav=row();nav.setPadding(10,10,10,10);nav.setBackgroundColor(BG);
        Button b1=button("＋ Montar ficha",true);Button b2=button("Alunos e fichas",false);
        b1.setOnClickListener(v->showBuilder());b2.setOnClickListener(v->showStudents());
        nav.addView(b1,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=8;nav.addView(b2,p);root.addView(nav);
        ScrollView scroll=new ScrollView(this);body=column();body.setPadding(14,4,14,20);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    Button button(String label,boolean primary){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTypeface(null,Typeface.BOLD);b.setTextColor(primary?Color.BLACK:WHITE);b.setBackground(bg(primary?GOLD:Color.rgb(45,45,45),24,primary?GOLD:Color.rgb(65,65,65)));b.setPadding(6,4,6,4);return b;}
    void card(String title){LinearLayout c=column();c.setPadding(15,14,15,15);c.setBackground(bg(CARD,24,Color.rgb(48,48,48)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=12;body.addView(c,p);if(title!=null)c.addView(text(title,19,WHITE,true));current=c;}
    LinearLayout current;
    EditText edit(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setHint(hint);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setTextSize(15);e.setPadding(12,8,12,8);e.setBackground(bg(Color.rgb(14,14,14),14,Color.rgb(65,65,65)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=5;p.bottomMargin=5;current.addView(e,p);return e;}
    Spinner spinner(String[] values){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);s.setAdapter(a);s.setBackground(bg(Color.rgb(14,14,14),12,Color.rgb(65,65,65)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=5;p.bottomMargin=5;current.addView(s,p);return s;}
    void addButton(String label,Runnable action,boolean primary){Button b=button(label,primary);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=8;current.addView(b,p);b.setOnClickListener(v->action.run());}
    void showBuilder(){
        screen="builder";body.removeAllViews();draft.clear();
        card("Montar ficha para aluno");
        studentInput=edit("Nome do aluno *","");
        current.addView(text("Objetivo",12,MUTED,false));goalSpinner=spinner(goals);
        current.addView(text("Divisão do treino",12,MUTED,false));splitSpinner=spinner(splits);
        current.addView(text("Nível",12,MUTED,false));levelSpinner=spinner(levels);
        notesInput=edit("Observações para o aluno (opcional)","");
        card("Adicionar exercícios");
        current.addView(text("Exercício",12,MUTED,false));Spinner ex=spinner(exercises);
        exerciseInput=edit("Ou digite exercício personalizado","");
        setsInput=edit("Séries","3");setsInput.setInputType(2);repsInput=edit("Repetições (ex.: 10–12)","10–12");
        restInput=edit("Descanso em segundos","60");restInput.setInputType(2);loadInput=edit("Carga (opcional)","");
        addButton("＋ Adicionar exercício",()->{
            String name=exerciseInput.getText().toString().trim();if(name.isEmpty())name=ex.getSelectedItem().toString();
            JSONObject o=new JSONObject();try{o.put("name",name);o.put("sets",setsInput.getText().toString().trim().isEmpty()?"3":setsInput.getText().toString());o.put("reps",repsInput.getText().toString().trim().isEmpty()?"10–12":repsInput.getText().toString());o.put("rest",restInput.getText().toString().trim().isEmpty()?"60":restInput.getText().toString());o.put("load",loadInput.getText().toString());draft.add(o);}catch(Exception ignored){}
            exerciseInput.setText("");renderDraft();
        },false);
        card("Exercícios adicionados");renderDraftInCurrent();
        addButton("SALVAR FICHA NO CELULAR",()->saveWorkout(),true);
        body.addView(text("Funciona sem internet. As fichas ficam guardadas neste aparelho.",12,MUTED,false));
    }
    void renderDraft(){if(!"builder".equals(screen))return;showBuilderDraftRefresh();}
    void showBuilderDraftRefresh(){/* draft display is refreshed when the page is re-opened; the list is also summarized below by toast */}
    void renderDraftInCurrent(){
        if(draft.isEmpty())current.addView(text("Ainda não adicionou exercícios.",13,MUTED,false));
        else for(int i=0;i<draft.size();i++){JSONObject o=draft.get(i);current.addView(text((i+1)+". "+o.optString("name")+" — "+o.optString("sets")+" × "+o.optString("reps")+" · descanso "+o.optString("rest")+"s",13,WHITE,false));}
    }
    JSONArray saved(){try{return new JSONArray(prefs.getString("workouts","[]"));}catch(Exception e){return new JSONArray();}}
    void saveWorkout(){
        String name=studentInput.getText().toString().trim();if(name.isEmpty()){studentInput.setError("Digite o nome do aluno");return;}if(draft.isEmpty()){new AlertDialog.Builder(this).setMessage("Adicione pelo menos um exercício.").setPositiveButton("OK",null).show();return;}
        try{JSONObject w=new JSONObject();w.put("id",System.currentTimeMillis());w.put("student",name);w.put("goal",goalSpinner.getSelectedItem().toString());w.put("split",splitSpinner.getSelectedItem().toString());w.put("level",levelSpinner.getSelectedItem().toString());w.put("notes",notesInput.getText().toString());w.put("date",new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date()));JSONArray a=new JSONArray();for(JSONObject o:draft)a.put(o);w.put("exercises",a);JSONArray all=saved();all.put(0,w);prefs.edit().putString("workouts",all.toString()).apply();new AlertDialog.Builder(this).setMessage("Ficha salva neste celular!").setPositiveButton("OK",(d,which)->showStudents()).show();}catch(Exception e){Toast.makeText(this,"Não foi possível salvar.",Toast.LENGTH_LONG).show();}
    }
    void showStudents(){screen="students";body.removeAllViews();card("Alunos e fichas salvas");JSONArray all=saved();if(all.length()==0)current.addView(text("Nenhuma ficha salva ainda. Toque em Montar ficha para criar a primeira.",14,MUTED,false));for(int i=0;i<all.length();i++){JSONObject w=all.optJSONObject(i);if(w==null)continue;LinearLayout item=column();item.setPadding(12,12,12,12);item.setBackground(bg(Color.rgb(15,15,15),16,Color.rgb(55,55,55)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=7;current.addView(item,p);item.addView(text(w.optString("student"),17,GOLD,true));item.addView(text(w.optString("date")+" · "+w.optString("goal")+" · "+w.optString("split"),12,MUTED,false));item.addView(text(w.optJSONArray("exercises").length()+" exercícios",13,WHITE,false));Button view=button("Ver ficha",false);item.addView(view);view.setOnClickListener(v->viewWorkout(w));Button del=button("Excluir ficha",false);item.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Excluir esta ficha?").setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(d,which)->{deleteWorkout(w.optLong("id"));showStudents();}).show());}
        addButton("＋ Montar nova ficha",()->showBuilder(),true);
    }
    void deleteWorkout(long id){JSONArray old=saved(),n=new JSONArray();for(int i=0;i<old.length();i++){JSONObject w=old.optJSONObject(i);if(w!=null&&w.optLong("id")!=id)n.put(w);}prefs.edit().putString("workouts",n.toString()).apply();}
    void viewWorkout(JSONObject w){StringBuilder s=new StringBuilder();s.append("Aluno: ").append(w.optString("student")).append("\nObjetivo: ").append(w.optString("goal")).append("\nDivisão: ").append(w.optString("split")).append("\nNível: ").append(w.optString("level")).append("\nData: ").append(w.optString("date")).append("\n\n");JSONArray a=w.optJSONArray("exercises");for(int i=0;a!=null&&i<a.length();i++){JSONObject e=a.optJSONObject(i);s.append(i+1).append(". ").append(e.optString("name")).append(" — ").append(e.optString("sets")).append(" séries × ").append(e.optString("reps")).append("; descanso ").append(e.optString("rest")).append("s");if(!e.optString("load").isEmpty())s.append("; carga ").append(e.optString("load"));s.append("\n");}if(!w.optString("notes").isEmpty())s.append("\nObservações: ").append(w.optString("notes"));new AlertDialog.Builder(this).setTitle("Ficha de treino").setMessage(s.toString()).setPositiveButton("Fechar",null).show();}
}
